package com.example.DemoLacart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoLacartApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoLacartApplication.class, args);
	}

}
